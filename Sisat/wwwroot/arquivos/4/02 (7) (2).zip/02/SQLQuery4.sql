USE Sis_Atualizacoes;

Insert into NiveisDeAcesso(ID_Nivel,NomeNivel) values(2,'CONVENIADO');

select * from NiveisDeAcesso;
select * from Usuario;
select * from Conveniados;



Update Usuario 
SET ID_Nivel = 2
WHERE ID = 1;


select * from conveniados;

