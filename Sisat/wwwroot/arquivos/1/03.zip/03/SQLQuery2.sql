Use Sis_Atualizacoes;

select * from Convenio_Projeto;

ALTER TABLE usuario
ADD login VARCHAR(255);

Insert into Usuario
	values('Juliandsonbarros@gmail.com','anderson Barros','123456', 'Anderson.Soares');

Insert into Usuario
	values('Juliandsonbs@gmail.com','Juliandson Barros Soares','123456', 'Juliandson.Barros');

Update Usuario 
SET Nome = 'Andson Soares'
WHERE ID = 1;

select p.Nom_projeto,pa.Id_Pacote, pa.Registro_Alteracoes from Projetos as p
inner join Pacotes_Atualizacoes as pa
on p.Id_Projeto = pa.Id_Pacote
where Nom_Projeto = 'Pai';

SELECT * FROM CONVENIADOS;
SELECT * FROM PROJETOS;
SELECT * FROM PACOTES_ATUALIZACOES;
SELECT * FROM CONVENIO_PROJETO;

insert into Conveniados(Nom_Conveniado) values('MPM-RJ');
insert into Conveniados(Nom_Conveniado) values('MPM-GO');
insert into Conveniados(Nom_Conveniado) values('MPM-SP');
insert into Conveniados(Nom_Conveniado) values('MPM-RS');
insert into Conveniados(Nom_Conveniado) values('MPM-MG');




insert into Projetos(Nom_Projeto) values('ARGUS');
insert into Projetos(Nom_Projeto) values('SITEL');
insert into Projetos(Nom_Projeto) values('SIMBA');
insert into Projetos(Nom_Projeto) values('PAI');
insert into Projetos(Nom_Projeto) values('PASSAPORT');

insert into Pacotes_Atualizacoes(Id_Proj,Num_Versao,Registro_Alteracoes,Dt_lancamento) values(4,'4444444444','ALTERA��O SISTEMA 4','2023-10-12');
insert into Pacotes_Atualizacoes(Id_Proj,Num_Versao,Registro_Alteracoes,Dt_lancamento) values(3,'3333333333','ALTERA��O SISTEMA 3','2023-10-12');
insert into Pacotes_Atualizacoes(Id_Proj,Num_Versao,Registro_Alteracoes,Dt_lancamento) values(1,'1111111111','ALTERA��O SISTEMA 1','2023-10-12');
insert into Pacotes_Atualizacoes(Id_Proj,Num_Versao,Registro_Alteracoes,Dt_lancamento) values(2,'2222222222','ALTERA��O SISTEMA 2','2023-10-12');
insert into Pacotes_Atualizacoes(Id_Proj,Num_Versao,Registro_Alteracoes,Dt_lancamento) values(5,'5555555555','ALTERA��O SISTEMA 5','2023-10-12');

insert into Convenio_Projeto(Id_Con,ID_Proj) values(1,4);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(1,5);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(1,3);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(5,3);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(5,4);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(4,2);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(4,1);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(2,2);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(3,5);
insert into Convenio_Projeto(Id_Con,ID_Proj) values(3,2);

select c.Nom_Conveniado,p.Nom_Projeto,Num_Versao,Dt_Lancamento
	from Conveniados as C inner join Projetos as p 
	on c.Id_Conveniado = p.Id_Projeto
	inner join Pacotes_Atualizacoes as pa
	on c.Id_Conveniado = pa.Id_Proj;

select c.Nom_Conveniado, p.Nom_Projeto 
	from Conveniados as c
	inner join Projetos as p 
	on c.Id_Conveniado = p.Id_Projeto;

ALTER TABLE Usuario 
ADD Id_usuario VARCHAR(255);


ALTER TABLE Conveniados
ADD CONSTRAINT FK_ID_Usuario
FOREIGN KEY(Id_usuario)
REFERENCES Usuario(Id);

ALTER TABLE Usuario
DROP COLUMN id_usuario;

select * from Conveniados;


ALTER TABLE Conveniados
ADD UsuarioID INT,
FOREIGN KEY (UsuarioID) REFERENCES Usuario(ID);

ALTER TABLE Conveniados
ADD ID_Usuario INT;


ALTER TABLE Conveniados
ADD CONSTRAINT FK_Usuario_Conveniado
FOREIGN KEY (ID_Usuario) REFERENCES Usuario(ID);

ALTER TABLE Conveniados
DROP COLUMN ID_Usuario;


CREATE TABLE NiveisDeAcesso (
    ID_Nivel INT PRIMARY KEY,
    NomeNivel VARCHAR(255),
);



ALTER TABLE Usuario
ADD ID_Nivel INT;


ALTER TABLE Usuario
ADD CONSTRAINT FK_Usuario_Nivel
FOREIGN KEY (ID_Nivel) REFERENCES NiveisDeAcesso(ID_Nivel);

Select * from CONVENIADOS;

insert into NiveisDeAcesso(NomeNivel) values('ADMIN');
insert into NiveisDeAcesso(NomeNivel) values('CONVENIADO');

insert into NiveisDeAcesso(NomeNivel) values('ADMIN');